package database;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class MongoDatabase {
	public DB db = null;
	public String collections = "";
	DBCollection Tweets = null;
	DBCollection localEvents = null;
	DBCollection QueryWindows = null;
	DBCollection Citys = null;

	public MongoDatabase() {

	}

	public void initialDB() {// initialize database, connecting to database and
								// open database
		try {

			// To connect to mongodb server
			MongoClient mongoClient = new MongoClient("localhost", 27017);

			// Now connect to your databases
			db = mongoClient.getDB("LocalEventDetectionDB");
			System.out.println("Connect to database successfully");

			Tweets = db.createCollection("Tweets", null);
			localEvents = db.createCollection("localEvents", null);
			QueryWindows = db.createCollection("QueryWindows", null);
			Citys = db.createCollection("Citys", null);

			// Delete All documents from collection Using blank BasicDBObject
//			BasicDBObject document = new BasicDBObject();
//			if (Tweets != null)
//				Tweets.remove(document);
//			if (localEvents != null)
//				localEvents.remove(document);
//			if (QueryWindows != null)
//				QueryWindows.remove(document);
//			if (Citys != null)
//				Citys.remove(document);
			// boolean auth = db.authenticate(myUserName, myPassword);
			// System.out.println("Authentication: "+auth);

		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}

	}

	// (a)write data to table Tweet
	public void writeTweet(long tweetId, long userId, long timestamp, double lng, double lat, String tag) {
		BasicDBObject doc = new BasicDBObject("_id", tweetId).append("userId", userId).append("timestamp", timestamp)
				.append("lng", lng).append("lat", lat).append("tag", tag);
		Tweets.insert(doc);
	}

	// (b)write data to localEvent
	public void writelocalEvent(long localeventId, long querywindowid, int rank, long tweetid) {
		BasicDBObject doc = new BasicDBObject("_id", localeventId).append("querywindowId", querywindowid)
				.append("rank", rank).append("tweetId", tweetid);
		localEvents.insert(doc);
	}
	public void writelocalEvent(BasicDBObject obj) {
		if(obj!=null)
		localEvents.insert(obj);
	}

	// (c)write data to QueryWindow
	public void writeQueryWindow(long querywindowid, long cityid, long startTS, long endTS) {
		BasicDBObject doc = new BasicDBObject("_id", querywindowid).append("cityId", cityid).append("startTS", startTS)
				.append("endTS", endTS);
		QueryWindows.insert(doc);
	}

	// (d)write data to City
	public void writeCity(long cityIndex, String name) {
		BasicDBObject doc = new BasicDBObject("_id", cityIndex).append("name", name);
		Citys.insert(doc);
	}

	// Read data from the database
	public String[] getLocalEvent(int cityName, long querywindowid, int numOfEvent) {

		// return a json list string which should be parsed by the front end
		BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put("querywindowId", querywindowid);
		// DBObject tweete = this.localEvents.findOne(whereQuery);
		DBCursor cursor = this.localEvents.find(whereQuery);
		String result = "";
		while (cursor.hasNext() && (numOfEvent) > 0) {
			DBObject doc = cursor.next();			
			result += doc.toString();
			if (numOfEvent > 1)
			result += "_ARRY_";			
			numOfEvent--;
		}
		return result.split("_ARRY_");
	}

	/**
	 * ---------------------------------- main
	 * ----------------------------------
	 **/
	public static void main(String[] args) throws Exception {
		MongoDatabase md = new MongoDatabase();
		md.initialDB();
		
		String[] result = md.getLocalEvent(0, 1, 10);
        
		for(int i=0;i<result.length;i++)
		System.out.println(result[i]);
		
//		DBCursor cursor = md.localEvents.find();
//		while (cursor.hasNext() ) {
//			DBObject doc = cursor.next();
//			System.out.println(doc.toString());
//		}

	}

}
